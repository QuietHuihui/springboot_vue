<template>
  <div>
    <el-button @click="add" type="primary">
      Add
    </el-button>
  </div>

  <el-dialog
    v-model="dialogVisible"
    title="Tips"
    width="30%"
    :before-close="handleClose"
  >
    <span>
      <el-form
        :label-position="labelPosition"
        label-width="100px"
        :model="form"
        style="max-width: 460px"
      >
        <el-form-item label="Name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="Region">
          <el-input v-model="form.region" />
        </el-form-item>
        <el-form-item label="Job">
          <el-input v-model="form.job" />
        </el-form-item>
      </el-form>
    </span>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false">Cancel</el-button>
        <el-button type="primary" @click="save">
          Confirm
        </el-button>
      </span>
    </template>
  </el-dialog>

  <el-table :data="tableData" stripe style="width: 100%">
    <el-table-column prop="name" label="Name"/>
    <el-table-column prop="region" label="Region"/>
    <el-table-column prop="job" label="Job" />
    <el-table-column fixed="right" label="Operations" width="120">
      <template #default="scope">
        <el-button link type="primary" size="small" @click="handleEdit(scope.row)">Edit</el-button>
        <el-popconfirm title="Are you sure to delete this?" @confirm="handleDelete(scope.row.id)">
          <template #reference>
          <el-button link type="primary" size="small">Delete</el-button>
      </template>
  </el-popconfirm>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
// @ is an alias to /src
import request from '@/utils/request'

export default {
  name: 'HomeView',
  data(){
    return{
      form:{},
      dialogVisible:false,
      tableData:[]
    }
  },
  created(){
    this.load()
  },
  methods:{
    add(){
      this.dialogVisible=true
    },
    load(){
      request.get("http://localhost:9090/user").then(
        res=>{
          this.tableData=res
        }
      )
    },
    save(){
      request.post("http://localhost:9090/user",this.form).then(
        res=>{
          this.load()
        }
      )
      this.dialogVisible=false
    },
    handleEdit(row){
      this.form=JSON.parse(JSON.stringify(row))
      this.dialogVisible=true
    },
    handleDelete(id){
      request.delete("http://localhost:9090/user/"+id).then(
        res=>{
          this.load()
        }
      )
    }
  }

}
</script>
